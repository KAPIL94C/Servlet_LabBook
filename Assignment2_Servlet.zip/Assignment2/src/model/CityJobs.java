package model;

import java.util.HashMap;
import java.util.List;

public class CityJobs {
	private String city;
	private String technology;
	private String[] jobList;
	
	
	public CityJobs(String city, String technology , String[] jobList) {
		super();
		this.city = city;
		this.technology=technology;
		this.jobList = jobList;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String[] getJobList() {
		return jobList;
	}
	public void setJobList(String[] jobList) {
		this.jobList = jobList;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	
	
}
