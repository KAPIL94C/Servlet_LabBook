package service;

import java.util.ArrayList;
import java.util.List;

import model.CityJobs;

public class JobService {
	String[] jobsd1= {"Full Stack","Web Developer"};
	CityJobs citytechd1=new CityJobs("Delhi", "Java", jobsd1);
	String[] jobsd2= {"AI","Robotics"};
	CityJobs citytechd2=new CityJobs("Delhi", "Python", jobsd2);
	String[] jobsm1= {"Web Developer","Web Designing"};
	CityJobs citytechm1=new CityJobs("Mumbai", "Angular", jobsm1);
	String[] jobsm2= {"AI","Robotics"};
	CityJobs citytechm2=new CityJobs("Mumbai", "R", jobsm2);
	String[] jobsb1= {"Full Stack","Server Developer"};
	CityJobs citytechb1=new CityJobs("Banglore", "Java", jobsb1);
	String[] jobsb2= {"Web Developer"};
	CityJobs citytechb2=new CityJobs("Banglore", ".Net", jobsb2);
	String[] jobsp1= {"Full Stack","Web Developer"};
	CityJobs citytechp1=new CityJobs("Pune", "Java", jobsp1);
	String[] jobsp2= {"AI"};
	CityJobs citytechp2=new CityJobs("Pune", "Python", jobsp2);
	String[] jobsh1= {"Full Stack"};
	CityJobs citytechh1=new CityJobs("Hyderabad", "Java", jobsh1);
	String[] jobsh2= {"AI","Robotics","Python Expert"};
	CityJobs citytechh2=new CityJobs("Hyderabad", "Python", jobsh2);
	CityJobs[] findJobList = {citytechd1,citytechd2,citytechm1,citytechm2,citytechp1,citytechp2,citytechh1,citytechh2};
	
	public List<String> getJobList(String technology, String city){
		List<String> jobslist = new ArrayList<String>();
		for(CityJobs job:findJobList) {
			if(job.getCity().equals(city) && job.getTechnology().equals(technology)) {
				for(String st:job.getJobList()) {
					jobslist.add(st);
				}
				return jobslist;
			}
		}
		jobslist.add("No Jobs Found");
		return jobslist;
	}
}
