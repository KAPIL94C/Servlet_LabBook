package com.capg.training.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capg.training.models.UserInfo;

public class UserDAOUtil {
	
	static Connection con;
	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","capg","capg");
			
			
		} catch (ClassNotFoundException e) {
			
			System.out.println(e);
		} catch (SQLException e) {
		
			System.out.println(e);
		}
		
		return con;
	}
	
		
	
	

}
