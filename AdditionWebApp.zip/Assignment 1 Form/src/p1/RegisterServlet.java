package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String username=request.getParameter("username");
		String pass=request.getParameter("password");
		String email=request.getParameter("email");
		int age=Integer.parseInt(request.getParameter("age"));
		String city=request.getParameter("city");
		String gender=request.getParameter("gender");
		String[] tech=request.getParameterValues("tech");
		
		    out.println("Name : "  + username);
		    out.println("<br>Password : "  + pass);
		    out.println("<br>Email : "  + email);
		    out.println("<br>Age : "  + age);
		    out.println("<br>City : "  + city);
		    out.println("<br>Gender : "+gender);
		    out.println("<br>Your technologies include<ul> ");
		    for (int i=0;i<tech.length; i++) {
		    out.println("<li>" + tech[i]);
		    }
		
		
	 
		
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
