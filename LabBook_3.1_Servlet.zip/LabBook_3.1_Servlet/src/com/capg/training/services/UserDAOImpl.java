package com.capg.training.services;

import java.sql.Connection;

public class UserDAOImpl implements UserDAO {

	static Connection con;
	public Connection getConnection(){
		con=UserDAOUtil.getConnection();
		return con;
	}
	
	
	

}
