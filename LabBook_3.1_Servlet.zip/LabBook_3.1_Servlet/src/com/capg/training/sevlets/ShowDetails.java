package com.capg.training.sevlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.training.models.UserInfo;
import com.capg.training.services.UserDAOImpl;
import com.capg.training.services.UserDAOUtil;

/**
 * Servlet implementation class ShowDetails
 */
public class ShowDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	out.println("<h3>Training Details</h3>");
		String getUser;

		
		try {
		
			Connection con=new UserDAOImpl().getConnection();
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from trainingdetails");
	         out.println("<table border='1'");  
          out.println("<tr><th>TrainingId</th><th>TrainingName</th><th>SeatsAvailable</th><tr>");
			 
			 while(rs.next()) {
				 int tID=rs.getInt(1);
				 String tName=rs.getString(2);
				 int  seats=rs.getInt(3);
		         out.println("<tr><td>" + tID + "</td><td>" + tName + "</td><td>" + seats +"</td><td><a href='EnrollServlet?id="+rs.getInt(1)+"&seats="+rs.getInt(3)+"'>Enroll</a>"+" " +"</td></tr>");   
             }  
			 
             out.println("</table>");  
             out.println("</html></body>"); 
				 
			 
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
